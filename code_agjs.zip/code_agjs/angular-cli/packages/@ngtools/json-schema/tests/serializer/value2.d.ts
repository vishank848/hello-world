interface _ {
    a?: ("v1" | "v2" | "v3")[];
    b?: (0 | 1 | "string" | true | null)[];
}
export default _;
