// import React from 'react';
// import { render } from 'react-dom';
// import { createStore } from 'redux';
// import { Provider } from 'react-redux';

// import App15 from './App15.jsx'
// import todoApp from './reducers/reducers'

// let store = createStore(todoApp)
// let rootElement = document.getElementById('app15')

// render(
//    <Provider store = {store}>
//       <App15 />
//    </Provider>,
	
//    rootElement
// )

import React from 'react';
import ReactDOM from 'react-dom';
import MyHOC from './MyHOC.jsx';


// ReactDOM.render(<App0 />, document.getElementById('app0'));
// ReactDOM.render(<App0 headerProp = "Header from props..." contentProp = "Content from props..."/>, document.getElementById('app0'));
// ReactDOM.render(<App7 />, document.getElementById('app7'));

ReactDOM.render( < MyHOC / > , document.getElementById('MyHOC'));


// {/* setTimeout(() => {ReactDOM.unmountComponentAtNode(document.getElementById('app7'));}, 10000); */}