module.exports = {
    entry: './main.js',
    output: {
       filename: 'bundle.js'
    },
    module: {
        rules: [
          {
             loader: 'babel-loader',
             test: /\.js$/,
             exclude: /node_modules/,
             query: {
                presets: ['es2015', 'react']
             }
          }
       ]
    },
    devServer: {
       port: 7777
    }
 };